"""
Constants for gravtools.
This module is part of the gravtools package.
Author: Andreas Hellerschmied
"""

VG_DEFAULT = 308.6  # muGal/m