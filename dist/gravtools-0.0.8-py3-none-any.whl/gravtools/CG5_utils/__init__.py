"""CG-5 gravity meter utility programms."""
