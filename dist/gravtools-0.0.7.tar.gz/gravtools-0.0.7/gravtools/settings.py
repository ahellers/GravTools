"""
gravtools
=========

Code by Andreas Hellerschmied
andeas.hellerschmid@bev.gv.at

Summary
-------
User-defined settings for gravtools.
"""

# Additive constant for the determination of the full absolute gravity [µGal] from observed values:
ADDITIVE_CONST_ABS_GRTAVITY = 9.8e8

SURVEY_DATA_SOURCE_TYPES = {
    'cg5_obs_file_txt': 'Scintrex CG5 observation file (text format)',
    'bev_obs_file': 'Simple observation file format used by BEV',
}

STATION_DATA_SOURCE_TYPES = {
    'oesgn_table': 'Control points of the Austrian gravity base network (OESGN).',
    'obs_file': 'From an observation file'
}

TIDE_CORRECTION_TYPES = {
    'cg5_longman1959': 'Instrument-implemented tidal correction of the Scintrex CG-5',
    'no_tide_corr': 'No tide correction applied',
    'unknown': 'Unknown whether a tide correction was applied',
}

REFERENCE_HEIGHT_TYPE = {
    'sensor_height': 'The gravity reverence point at the station is at the sensor height',
    'instrument_top': 'The gravity value refers to the height og the instrument top',
    'ground': 'The gravity value refers to the ground point at the station',
    'control_point': 'The gravity value refers to the control point at the station',
}

# Reference heights (sensor heights) of different gravimeter types:
GRAVIMETER_REFERENCE_HEIGHT_CORRECTIONS_m = {
    'CG3': -0.211,
    'CG5': -0.211,
}

# Valid gravimeter types and description.
GRAVIMETER_TYPES = {
    'CG5': 'Sctintrex CG5',
    'CG3': 'Sctintrex CG3',
}

# Default Gavimeter Type when loading data from an CG5 observation file
DEFAULT_GRAVIMETER_TYPE_CG5_SURVEY = 'CG5'

# Lookuptable to convert gravimeter type to Kennzeichen used at BEV (in the database NSDB):
GRAVIMETER_TYPES_KZG_LOOKUPTABLE = {
    'CG5': 'C',
    'CG3': 'C',
}

# Valid Gravimeter serial numbers (S/N and type)
GRAVIMETER_SERIAL_NUMBERS = {
    '40601': 'CG5',
    '40236': 'CG5',
}

# Lookuptable to convert the gravimeter S/N to the IDs written to the database NSDB:
GRAVIMETER_SERIAL_NUMBER_TO_ID_LOOKUPTABLE = {
    '40601': '5',
    '40236': '5',
}

#  Lookup table for matching gravimeter IDs and the tidal corrections that are applied per default in the BEV legacy
#  observation files:
BEV_GRAVIMETER_TIDE_CORR_LOOKUP = {
    '5': 'cg5_longman1959'
}

# Available adjustment methods:
ADJUSTMENT_METHODS = {
    'LSM_diff': 'LSM (differential observations)',  # Least-squares adjustment of differential observations
    'LSM_non_diff': 'LSM (non-differential observations)',  # Least-squares adjustment of non-differential observations
    'MLR_BEV': 'MLR (BEV legacy processing)',  # Least-squares adjustment of differential observations
}

# Available iteration approaches for scaling the SD of setup observations:
ITERATION_APPROACHES = {
    'Multiplicative': 'Multiplicative iteration approach',
    'Additive': 'Additive iteration approach'
}

# Treshold for the "Gewichtsreziprokenprobe nach Ansermet" (see Skriptum AG1, p. 136, Eq. (6.86))
ANSERMET_DIFF_TRESHOLD = 1e-3

# Treshold for the redundancy component of an observation in order to apply a pope test for outlier detection:
R_POPE_TEST_TRESHOLD = 1e-6

# GUI and Program options:
CALCULATE_REDUCED_OBS_WHEN_LOADING_DATA = True  # Calculate reduced observations when loading observation data.
INIT_OESGN_STATION_AS_DATUM = False  # Initialize OESGN stations as datum stations when loading rom an OESGN file?


# ----- GUI appearance and plot settings -----

# --- Drift plots in the results tab: ---
# Number of plot items for plotting the drift function (polynomial):
DRIFT_PLOT_NUM_ITEMS_IN_DRIFT_FUNCTION = 100
# Options for the observation data points in the drift plot:
DRIFT_PLOT_SCATTER_PLOT_SYMBOL_SIZE = 10
DRIFT_PLOT_SCATTER_PLOT_PEN_WIDTH = 1
DRIFT_PLOT_SCATTER_PLOT_PEN_COLOR = 'k'

# --- Correlation matrix in the results tab: ---
# Background color scheme for the correlation coefficient [0 - 1]
# - Get HEX colors from here: https://colorbrewer2.org/
# - https://www.pythonguis.com/tutorials/qtableview-modelviews-numpy-pandas/
# green (low correlation) => red (high correlation)
CORRELATION_COEF_COLORS = ['#006837', '#1a9850', '#66bd63', '#a6d96a', '#d9ef8b', '#fee08b', '#fdae61', '#f46d43', '#d73027', '#a50026']
# Background color for diagonal elements (=1):
CORRELATION_COEF_DIAG_ELEMENTS = '#bababa'  # light grey

# --- Data export options: ---
# List of columns in the `obs_df` dataframe that are written to the exported observation list CSV file:
EXPORT_OBS_LIST_COLUMNS = ['survey_name', 'obs_epoch', 'station_name', 'keep_obs']
# Maximum allowed SD of the estimated gravity at stations when exporting data to a nsb file!
#  => This is important as only 3 characters are reserved in the nsb file for the SD!
MAX_SD_FOR_EXPORT_TO_NSB_FILE = 999.0
# Choices for 5-character comment written to the nsb file (appears as Operat-G in the NSDB):
# - One letter instrument-ID: 'inst_id'
# - Official 5-character serial number of the Scintrex CG-5 Gravitimeters: 'cg5_serial_number'
# - Version of Gravtools: 'gravtools_version'
# !! Warning: Actually only the gravtools version makes sense, because multiple surveys observed with different
# instruments can be combindes
WRITE_COMMENT_TO_NSB = 'gravtools_version'


# ----- SCHWAUS and DRIFT settings (legacy code) -----

# Instrumenten-IDs in der Messdatei einem Instrument zuweisen:
GRAVIMETER_ID_BEV = {
    '3': 'CG3',
    '5': 'CG5',
}

# Instrumenten-IDs in der Messdatei einem Instrumenten-KZ zuweisen:
GRAVIMETER_KZ_BEV = {
    '3': 'C',
    '5': 'C',
    '9': 'D',
    '90': 'D',
    '900': 'D',
    '51': 'D',
    '510': 'D',
    '500': 'W',
}

FLAG_SAVE_DRIFT_PLOT_PDF = True
FLAG_CREATE_SCHWAUS_PROTOCOL = True
VERBOSE = True

# Output directory
OUT_PATH = '/home/heller/pyProjects/gravtools/out'

# Default names and paths of input files:

# ÖSGN Table:
PATH_OESGN_TABLE = '/home/heller/pyProjects/gravtools/data/'
NAME_OESGN_TABLE = 'OESGN.TAB'

# BEV observation files:
PATH_OBS_FILE_BEV = '/home/heller/pyProjects/gravtools/data/BEV/'
# NAME_OBS_FILE_BEV = '20200527_tideCorr'
# NAME_OBS_FILE_BEV = '20200527_sd'
# NAME_OBS_FILE_BEV = '20200527_2'
# NAME_OBS_FILE_BEV = '20200527'
NAME_OBS_FILE_BEV = 'n20200701_1'
# NAME_OBS_FILE_BEV = 'e201001'

# CG-5 observation files (text)
PATH_OBS_FILE_CG5 = '/home/heller/pyProjects/gravtools/data/CG5/'
# NAME_OBS_FILE_CG5 = '2020-06-18_DACH.TXT'
NAME_OBS_FILE_CG5 = '20200907_test.TXT'
