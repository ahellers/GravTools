"""
gravtools
=========

Code by Andreas Hellerschmied
andeas.hellerschmid@bev.gv.at

Summary
-------
Program collection for handling gravity surveys.
"""

__version__ = '0.0.8'
__author__ = 'Andreas Hellerschmied'